import java.util.Scanner;
import java.util.Queue;
import java.util.LinkedList;

class MazeNode{
    int row , col , distance , numTwos;
    MazeNode(int row , int col , int distance , int numTwos){
        this.row = row;
        this.col = col;
        this.distance = distance;
        this.numTwos = numTwos;
    }
}
public class MazeRunner{
    public static void main(String args[]){
        Scanner sc= new Scanner(System.in);
        int R = sc.nextInt();
        int C = sc.nextInt();
        int[][] maze = new int[R][C];
        for(int i=0;i<R ;i++){
            for(int j=0;j<C;j++){
                maze[i][j] = sc.nextInt();
            }
        }
        int startRow = sc.nextInt();
        int startCol = sc.nextInt();
        int targetRow = sc.nextInt();
        int targetCol = sc.nextInt();
        int result = findShortestPath(maze , R ,C ,startRow , startCol , targetRow , targetCol);
        System.out.println(result == Integer.MAX_VALUE ? "STUCK" : result);
        sc.close();
    }
    private static int findShortestPath(int[][] maze , int R , int C , int startRow , int startCol , int targetRow , int targetCol){
        int[][] visited = new int[R][C];

        Queue<MazeNode> queue = new LinkedList<>();
        queue.add(new MazeNode(startRow , startCol , 0 , 0));
        visited[startRow][startCol] = 1;
        int[] rowOffset = {-1 , 1 , 0 , 0};
        int[] colOffset = {0 , 0 , -1 ,1};
        while(!queue.isEmpty()){
            MazeNode current = queue.poll();
            if(current.row == targetRow && current.col == targetCol){
                return current.distance;
            }
            for(int i=0 ;i<4 ;i++){
                int newRow = current.row+rowOffset[i];
                int newCol = current.col +colOffset[i];
                if(isValid(newRow , newCol , R , C) && maze[newRow][newCol] != 1 && visited[newRow][newCol] ==0){
                    int newTwos = current.numTwos + (maze[newRow][newCol] == 2 ? 1 :0);
                    if(maze[newRow][newCol] == 3 && newTwos >1){
                        continue;
                    }
                    visited[newRow][newCol] = 1;
                    queue.add(new MazeNode(newRow , newCol , current.distance +1 , newTwos));
                }
            }
        }
        return Integer.MAX_VALUE;
    }
    private static boolean isValid(int row , int col , int R , int C ){
        return row>=0 && row <R && col>=0 && col<C;
    }
}