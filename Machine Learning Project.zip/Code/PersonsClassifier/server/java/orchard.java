import java.util.Scanner;
import java.util.*;
public class orchard{
    public static void main(String args[]){
        Scanner sc= new Scanner(System.in);
    
        String ashokRow = sc.nextLine();
        String anandRow = sc.nextLine();

        int ashokPossibilities = countPossibilities(ashokRow);
        int anandPossibilities = countPossibilities(anandRow);

        String winner = determineWinner(ashokPossibilities , anandPossibilities);
        System.out.println(winner);
        sc.close();
    }
    private static int countPossibilities(String row){
        int possibilities = 0;
        int n=row.length();

        for(int i=0;i<n-2;i++){
            if(row.charAt(i) != row.charAt(i+1) && row.charAt(i+1) != row.charAt(i+2) && row.charAt(i) != row.charAt(i+2)){
                possibilities++;
            }
        }
        return possibilities;
    }
    private static String determineWinner(int ashokPossibilities , int anandPossibilities){
        if(ashokPossibilities > anandPossibilities){
            return "Ashok";
        }
        else if(anandPossibilities > ashokPossibilities){
            return "Anand";
        }
        else{
            return "Draw";
        }
    }
}