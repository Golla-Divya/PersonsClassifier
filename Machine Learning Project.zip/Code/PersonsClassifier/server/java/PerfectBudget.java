import java.util.Arrays;
import java.util.Scanner;

class Project{
    int expenditure , bonus , rewardOrPenality;
    Project(int expenditure , int bonus , int rewardOrPenality){
        this.expenditure = expenditure;
        this.bonus = bonus;
        this.rewardOrPenality = rewardOrPenality;
    }
}
public class PerfectBudget{
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        Project[] projects = new Project[n];
        for(int i=0 ;i<n ;i++){
            int expenditure = sc.nextInt();
            int bonus = sc.nextInt();
            int rewardOrPenality = sc.nextInt();
            projects[i] = new Project(expenditure , bonus , rewardOrPenality);
        }
        int result = calculateMinimumBudget(projects);
        System.out.println(result);
        sc.close();
    }
    private static int calculateMinimumBudget(Project[] projects){
        Arrays.sort(projects , (a , b) -> Integer.compare(a.bonus - a.rewardOrPenality, b.bonus - b.rewardOrPenality));
        int minBudget = 0;
        int currentBudget = 0;
        for(Project project :projects){
            if(currentBudget +project.expenditure<0){
                minBudget+=Math.abs(currentBudget + project.expenditure);
                currentBudget =0 ;
            }
            currentBudget += project.bonus - project.rewardOrPenality;
        }
        return minBudget;
    }
}
