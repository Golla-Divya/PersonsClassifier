def max_earnings(N , M , quality_quailable , quality_needed , coset_of_one_unit , selling_price):
    max_amount = 0
    for i in range(M):
        if quality_quailable[i] >quality_needed[i]:
            max_toys = N // quality_needed[i]
            amount = max_toys * selling_price[i] - max_toys*coset_of_one_unit[i]
            max_amount = max(max_amount ,amount)
    return max_amount

N ,M = map(int , input().split())
quality_quailable =list(map(int , input().split()))
quality_needed =list(map(int , input().split()))
coset_of_one_unit=list(map(int , input().split()))
selling_price =list(map(int , input().split()))

print(max_earnings (N ,M , quality_quailable , quality_needed , coset_of_one_unit , selling_price))
