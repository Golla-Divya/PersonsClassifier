import java.util.Scanner;
public class VinniTheCraftsman{
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        int M = sc.nextInt();
        int[] qualityAvailable = new int[M];
        int[] qualityNeeded = new int[M];
        int[] costOfOneUnit = new int[M];
        int[] sellingPrice = new int[M];
        for(int i=0 ;i<M ; i++){
            qualityAvailable[i] = sc.nextInt();
        }
        for(int i=0 ;i<M ;i++){
            qualityNeeded[i] = sc.nextInt();
        }
        for(int i=0 ;i<M ;i++){
            costOfOneUnit[i] = sc.nextInt();
        }
        for(int i=0 ;i<M ;i++){
            sellingPrice[i] = sc.nextInt();
        }
        int maxAmount = 0; 
        for(int i=0; i<M ;i++){
            if(qualityAvailable[i] >= qualityNeeded[i]){
                int maxToys = N/qualityNeeded[i];
                int amount = maxToys *sellingPrice[i] - maxToys *costOfOneUnit[i];
                maxAmount = Math.max(maxAmount ,amount);
            }
        }
        System.out.println(maxAmount);
        
    }
}