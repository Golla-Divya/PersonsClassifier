import java.util.Scanner;
import java.util.*;
public class BestBubble{
    private static int bubbleSort(int[] arr , boolean ascending){
        int n = arr.length;
        int swaps = 0;
        for(int i=0 ; i<n-1 ;i++){
            for(int j=0 ; j<n-i-1 ;j++){
                if((ascending && arr[j] > arr[j+1]) || (!ascending && arr[j] < arr[j+1])){
                    int temp= arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                    swaps++;
                }
            }
        }
        System.out.println();
        return swaps;
        
    }
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        System.out.println();
        int[] arr = new int[N];
        for(int i=0;i<N ;i++){
            arr[i] = sc.nextInt();
        }
        int ascendingSwaps = bubbleSort(Arrays.copyOf(arr , arr.length) ,true);
        int descendingSwaps = bubbleSort(Arrays.copyOf(arr , arr.length) ,false);
        int minSwaps = Math.min(ascendingSwaps , descendingSwaps);
        System.out.println(minSwaps);
        sc.close();
    }
}
